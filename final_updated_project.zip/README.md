
# Marine Ecosystem Conservation Dashboard

## Steps to Run the Project

1. **Install Node.js and npm**:
   - Ensure Node.js (v16 or later) and npm are installed on your system.
   - Check versions:
     ```bash
     node -v
     npm -v
     ```

2. **Install Dependencies**:
   - Navigate to the project directory:
     ```bash
     cd project
     ```
   - Install all required dependencies:
     ```bash
     npm install
     ```

3. **Set Up Environment Variables**:
   - Configure the `.env` file with the following:
     ```env
     MAPBOX_TOKEN=your_mapbox_api_token
     NOAA_API_KEY=your_noaa_api_key
     OPENWEATHERMAP_API_KEY=your_openweathermap_api_key
     ```

4. **Run the Development Server**:
   - Start the server with increased memory allocation:
     ```bash
     npm run start:dev
     ```
   - The server will start at `http://localhost:3000`.

5. **Troubleshooting**:
   - If the map doesn’t load, ensure your **Mapbox API Token** is valid.
   - For external data errors, verify your API keys in the `.env` file.
   - Use `npm run build` to create a production build if needed.

