export interface ClimateMetrics {
  carbonFootprint: number;
  seaLevelRise: number;
  oceanAcidity: number;
  waterTemperature: number;
}

export interface ClimateImpact {
  severity: 'low' | 'medium' | 'high';
  recommendations: string[];
  timestamp: string;
}

export interface ClimateAction {
  id: string;
  type: 'mitigation' | 'adaptation';
  description: string;
  impact: number;
  status: 'planned' | 'in-progress' | 'completed';
}