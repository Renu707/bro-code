export interface MarineData {
  temperature: number;
  pollutionLevel: number;
  biodiversityIndex: number;
  location: [number, number];
  timestamp: string;
}

export interface AlertConfig {
  temperatureThreshold: number;
  pollutionThreshold: number;
  enabled: boolean;
}

export interface MapMarker {
  id: string;
  longitude: number;
  latitude: number;
  type: 'biodiversity' | 'pollution' | 'restoration';
  value: number;
}