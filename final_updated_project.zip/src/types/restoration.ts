export interface RestorationProject {
  id: string;
  name: string;
  location: [number, number];
  type: 'coral' | 'mangrove' | 'seagrass' | 'wetland';
  status: 'planned' | 'active' | 'completed';
  progress: number;
  impact: {
    areaRestored: number;
    speciesProtected: number;
    carbonSequestered: number;
  };
}

export interface RestorationMetrics {
  totalProjects: number;
  activeProjects: number;
  totalAreaRestored: number;
  totalCarbonSequestered: number;
}