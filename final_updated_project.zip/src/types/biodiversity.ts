export interface Species {
  id: string;
  name: string;
  population: number;
  trend: 'increasing' | 'stable' | 'decreasing';
  threatLevel: 'least-concern' | 'vulnerable' | 'endangered' | 'critical';
}

export interface Habitat {
  id: string;
  type: string;
  healthIndex: number;
  area: number;
  dominantSpecies: string[];
}

export interface BiodiversityMetrics {
  speciesCount: number;
  endangeredCount: number;
  habitatHealth: number;
  ecosystemStability: number;
}