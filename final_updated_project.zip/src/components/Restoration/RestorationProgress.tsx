import React from 'react';
import { RestorationProject } from '../../types/restoration';
import { Leaf, TreePine, Waves } from 'lucide-react';

interface RestorationProgressProps {
  projects: RestorationProject[];
}

export const RestorationProgress: React.FC<RestorationProgressProps> = ({ projects }) => {
  const getProjectIcon = (type: RestorationProject['type']) => {
    switch (type) {
      case 'coral': return <Waves className="text-blue-500" />;
      case 'mangrove': return <TreePine className="text-green-500" />;
      case 'seagrass': return <Leaf className="text-emerald-500" />;
      case 'wetland': return <Waves className="text-cyan-500" />;
    }
  };

  return (
    <div className="bg-white rounded-lg p-4 shadow-md">
      <h3 className="text-lg font-semibold mb-4">Restoration Projects</h3>
      <div className="space-y-4">
        {projects.map((project) => (
          <div key={project.id} className="border rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                {getProjectIcon(project.type)}
                <span className="font-medium">{project.name}</span>
              </div>
              <span className="text-sm text-gray-500">{project.type}</span>
            </div>
            
            <div className="mb-2">
              <div className="flex justify-between text-sm mb-1">
                <span>Progress</span>
                <span>{project.progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-500 rounded-full h-2 transition-all duration-500"
                  style={{ width: `${project.progress}%` }}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-sm text-gray-600">
              <div>
                <p className="text-xs">Area Restored</p>
                <p className="font-medium">{project.impact.areaRestored} ha</p>
              </div>
              <div>
                <p className="text-xs">Species Protected</p>
                <p className="font-medium">{project.impact.speciesProtected}</p>
              </div>
              <div>
                <p className="text-xs">Carbon Sequestered</p>
                <p className="font-medium">{project.impact.carbonSequestered} tons</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};