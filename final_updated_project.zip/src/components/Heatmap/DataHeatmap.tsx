import React, { useMemo } from 'react';
import { MarineData } from '../../types';

interface DataHeatmapProps {
  data: MarineData[];
  metric: keyof Pick<MarineData, 'temperature' | 'pollutionLevel' | 'biodiversityIndex'>;
}

export const DataHeatmap: React.FC<DataHeatmapProps> = ({ data, metric }) => {
  const colorScale = useMemo(() => {
    const values = data.map(d => d[metric]);
    const max = Math.max(...values);
    const min = Math.min(...values);
    
    return (value: number) => {
      const normalized = (value - min) / (max - min);
      const hue = metric === 'pollutionLevel' ? 
        0 : // Red for pollution
        metric === 'temperature' ? 
          200 : // Blue for temperature
          120; // Green for biodiversity
      return `hsla(${hue}, 80%, ${50 - normalized * 30}%, ${0.3 + normalized * 0.7})`;
    };
  }, [data, metric]);

  return (
    <div className="relative w-full h-48 bg-gray-50 rounded-lg overflow-hidden">
      {data.map((point, index) => (
        <div
          key={index}
          className="absolute w-12 h-12 rounded-full transform -translate-x-1/2 -translate-y-1/2 transition-all duration-500"
          style={{
            backgroundColor: colorScale(point[metric]),
            left: `${((point.location[0] + 122.4194) * 100) % 100}%`,
            top: `${((point.location[1] - 37.7749) * 100) % 100}%`,
          }}
        />
      ))}
      <div className="absolute bottom-2 right-2 bg-white px-2 py-1 rounded text-sm">
        {metric.replace(/([A-Z])/g, ' $1').toLowerCase()}
      </div>
    </div>
  );
};