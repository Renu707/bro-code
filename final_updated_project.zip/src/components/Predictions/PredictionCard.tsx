import React from 'react';
import { TrendingUp } from 'lucide-react';
import { MarineData } from '../../types';

interface PredictionCardProps {
  current: MarineData;
  predicted: MarineData;
}

export const PredictionCard: React.FC<PredictionCardProps> = ({ current, predicted }) => {
  const metrics: Array<{
    key: keyof Pick<MarineData, 'temperature' | 'pollutionLevel' | 'biodiversityIndex'>;
    label: string;
    unit: string;
  }> = [
    { key: 'temperature', label: 'Temperature', unit: '°C' },
    { key: 'pollutionLevel', label: 'Pollution', unit: '%' },
    { key: 'biodiversityIndex', label: 'Biodiversity', unit: '' },
  ];

  return (
    <div className="bg-white rounded-lg p-4 shadow-md">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="text-blue-500" />
        <h3 className="text-lg font-semibold">Predictions</h3>
      </div>
      <div className="space-y-4">
        {metrics.map(({ key, label, unit }) => {
          const trend = predicted[key] - current[key];
          const trendColor = trend > 0 ? 'text-green-500' : 'text-red-500';
          
          return (
            <div key={key} className="flex justify-between items-center">
              <span className="text-gray-600">{label}</span>
              <div className="flex items-center gap-2">
                <span>{predicted[key].toFixed(1)}{unit}</span>
                <span className={`text-sm ${trendColor}`}>
                  ({trend > 0 ? '+' : ''}{trend.toFixed(1)}{unit})
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};