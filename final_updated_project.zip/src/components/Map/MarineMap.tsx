import React, { useState } from 'react';
import Map, { Marker } from 'react-map-gl';
import { MapMarker } from '../../types';
import { AlertTriangle, Trees, Fish } from 'lucide-react';
import 'mapbox-gl/dist/mapbox-gl.css';

interface MarineMapProps {
  markers: MapMarker[];
}

export const MarineMap: React.FC<MarineMapProps> = ({ markers }) => {
  const [mapError, setMapError] = useState<string | null>(null);

  const getMarkerIcon = (type: MapMarker['type']) => {
    switch (type) {
      case 'pollution':
        return AlertTriangle;
      case 'restoration':
        return Trees;
      case 'biodiversity':
        return Fish;
    }
  };

  const getMarkerColor = (type: MapMarker['type']) => {
    switch (type) {
      case 'pollution':
        return 'text-red-500';
      case 'restoration':
        return 'text-green-500';
      case 'biodiversity':
        return 'text-blue-500';
    }
  };

  if (mapError) {
    return (
      <div className="h-full flex items-center justify-center bg-gray-50 rounded-lg">
        <p className="text-gray-500">{mapError}</p>
      </div>
    );
  }

  return (
    <Map
      initialViewState={{
        longitude: -122.4194,
        latitude: 37.7749,
        zoom: 11
      }}
      style={{ width: '100%', height: '100%' }}
      mapStyle="mapbox://styles/mapbox/light-v10"
      mapboxAccessToken={import.meta.env.VITE_MAPBOX_ACCESS_TOKEN}
      onError={(e) => setMapError("Failed to load map. Please check your connection.")}
    >
      {markers.map((marker) => {
        const Icon = getMarkerIcon(marker.type);
        return (
          <Marker
            key={marker.id}
            longitude={marker.longitude}
            latitude={marker.latitude}
          >
            <div className="relative group">
              <Icon className={`w-6 h-6 ${getMarkerColor(marker.type)}`} />
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 hidden group-hover:block">
                <div className="bg-white px-2 py-1 rounded shadow-md text-sm">
                  {marker.type}: {marker.value.toFixed(1)}
                </div>
              </div>
            </div>
          </Marker>
        )})}
    </Map>
  );
};