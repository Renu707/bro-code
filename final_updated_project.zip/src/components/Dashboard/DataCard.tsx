import React from 'react';
import { Droplets, Thermometer, Fish } from 'lucide-react';

interface DataCardProps {
  title: string;
  value: number;
  type: 'temperature' | 'pollution' | 'biodiversity';
  unit: string;
}

export const DataCard: React.FC<DataCardProps> = ({ title, value, type, unit }) => {
  const icons = {
    temperature: Thermometer,
    pollution: Droplets,
    biodiversity: Fish,
  };

  const Icon = icons[type];
  
  return (
    <div className="bg-white rounded-lg p-4 shadow-md">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-500">{title}</p>
          <p className="text-2xl font-bold mt-1">
            {value.toFixed(1)} {unit}
          </p>
        </div>
        <Icon className="w-8 h-8 text-blue-500" />
      </div>
    </div>
  );
};