import React from 'react';
import { Bell, BellOff } from 'lucide-react';
import { AlertConfig } from '../../types';

interface AlertSystemProps {
  config: AlertConfig;
  onConfigChange: (config: AlertConfig) => void;
}

export const AlertSystem: React.FC<AlertSystemProps> = ({ config, onConfigChange }) => {
  return (
    <div className="bg-white rounded-lg p-4 shadow-md">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Alert Configuration</h3>
        <button
          onClick={() => onConfigChange({ ...config, enabled: !config.enabled })}
          className="p-2 rounded-full hover:bg-gray-100"
        >
          {config.enabled ? <Bell className="text-blue-500" /> : <BellOff className="text-gray-400" />}
        </button>
      </div>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Temperature Threshold (°C)</label>
          <input
            type="number"
            value={config.temperatureThreshold}
            onChange={(e) => onConfigChange({ ...config, temperatureThreshold: Number(e.target.value) })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700">Pollution Threshold</label>
          <input
            type="number"
            value={config.pollutionThreshold}
            onChange={(e) => onConfigChange({ ...config, pollutionThreshold: Number(e.target.value) })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>
      </div>
    </div>
  );
};