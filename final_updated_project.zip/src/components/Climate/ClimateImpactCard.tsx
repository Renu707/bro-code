import React from 'react';
import { Cloud, Droplets, ThermometerSun } from 'lucide-react';
import { ClimateMetrics, ClimateImpact } from '../../types/climate';

interface ClimateImpactCardProps {
  metrics: ClimateMetrics;
  impact: ClimateImpact;
}

export const ClimateImpactCard: React.FC<ClimateImpactCardProps> = ({ metrics, impact }) => {
  const getSeverityColor = (severity: ClimateImpact['severity']) => {
    switch (severity) {
      case 'low': return 'text-green-500';
      case 'medium': return 'text-yellow-500';
      case 'high': return 'text-red-500';
    }
  };

  return (
    <div className="bg-white rounded-lg p-4 shadow-md">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Climate Impact</h3>
        <div className={`px-2 py-1 rounded ${getSeverityColor(impact.severity)} bg-opacity-10`}>
          {impact.severity.toUpperCase()}
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="flex items-center gap-2">
          <Cloud className="text-blue-500" />
          <div>
            <p className="text-sm text-gray-500">Carbon Footprint</p>
            <p className="font-semibold">{metrics.carbonFootprint} tons</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Droplets className="text-blue-500" />
          <div>
            <p className="text-sm text-gray-500">Ocean Acidity</p>
            <p className="font-semibold">pH {metrics.oceanAcidity}</p>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <p className="text-sm font-medium">Recommendations:</p>
        <ul className="text-sm text-gray-600 space-y-1">
          {impact.recommendations.map((rec, index) => (
            <li key={index} className="flex items-start gap-2">
              <span className="text-blue-500">•</span>
              {rec}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};