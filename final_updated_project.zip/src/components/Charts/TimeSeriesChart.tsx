import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { MarineData } from '../../types';

interface TimeSeriesChartProps {
  data: MarineData[];
}

export const TimeSeriesChart: React.FC<TimeSeriesChartProps> = ({ data }) => {
  return (
    <div className="h-64 w-full">
      <ResponsiveContainer>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="timestamp"
            tickFormatter={(value) => new Date(value).toLocaleTimeString()}
          />
          <YAxis />
          <Tooltip
            labelFormatter={(value) => new Date(value).toLocaleString()}
          />
          <Legend />
          <Line
            type="monotone"
            dataKey="temperature"
            stroke="#3b82f6"
            name="Temperature (°C)"
          />
          <Line
            type="monotone"
            dataKey="pollutionLevel"
            stroke="#ef4444"
            name="Pollution Level"
          />
          <Line
            type="monotone"
            dataKey="biodiversityIndex"
            stroke="#22c55e"
            name="Biodiversity Index"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};