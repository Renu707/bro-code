import { ClimateMetrics, ClimateImpact } from '../types/climate';

export const analyzeClimateImpact = (metrics: ClimateMetrics): ClimateImpact => {
  const severity = calculateSeverity(metrics);
  const recommendations = generateRecommendations(metrics, severity);

  return {
    severity,
    recommendations,
    timestamp: new Date().toISOString(),
  };
};

const calculateSeverity = (metrics: ClimateMetrics): ClimateImpact['severity'] => {
  const factors = [
    metrics.carbonFootprint > 1000,
    metrics.seaLevelRise > 2,
    metrics.oceanAcidity < 7.8,
    metrics.waterTemperature > 25,
  ];

  const criticalCount = factors.filter(Boolean).length;
  
  if (criticalCount >= 3) return 'high';
  if (criticalCount >= 1) return 'medium';
  return 'low';
};

const generateRecommendations = (
  metrics: ClimateMetrics,
  severity: ClimateImpact['severity']
): string[] => {
  const recommendations: string[] = [];

  if (metrics.carbonFootprint > 1000) {
    recommendations.push('Implement carbon reduction strategies in marine operations');
  }
  if (metrics.seaLevelRise > 2) {
    recommendations.push('Enhance coastal protection measures');
  }
  if (metrics.oceanAcidity < 7.8) {
    recommendations.push('Reduce local pollution sources affecting water pH');
  }
  if (metrics.waterTemperature > 25) {
    recommendations.push('Monitor and protect heat-sensitive marine species');
  }

  return recommendations;
};