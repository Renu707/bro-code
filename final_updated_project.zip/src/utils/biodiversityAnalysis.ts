import { Species, Habitat, BiodiversityMetrics } from '../types/biodiversity';

export const calculateBiodiversityMetrics = (
  species: Species[],
  habitats: Habitat[]
): BiodiversityMetrics => {
  const endangeredCount = species.filter(
    s => s.threatLevel === 'endangered' || s.threatLevel === 'critical'
  ).length;

  const habitatHealth = habitats.reduce(
    (acc, h) => acc + h.healthIndex,
    0
  ) / habitats.length;

  const ecosystemStability = calculateEcosystemStability(species, habitats);

  return {
    speciesCount: species.length,
    endangeredCount,
    habitatHealth,
    ecosystemStability,
  };
};

const calculateEcosystemStability = (
  species: Species[],
  habitats: Habitat[]
): number => {
  const speciesStability = species.reduce(
    (acc, s) => acc + (s.trend === 'stable' ? 1 : 0),
    0
  ) / species.length;

  const habitatStability = habitats.reduce(
    (acc, h) => acc + (h.healthIndex > 0.7 ? 1 : 0),
    0
  ) / habitats.length;

  return (speciesStability + habitatStability) / 2 * 100;
};