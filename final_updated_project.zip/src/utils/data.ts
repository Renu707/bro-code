import { MarineData, MapMarker } from '../types';

export const generateMockData = (): MarineData => ({
  temperature: 20 + Math.random() * 10,
  pollutionLevel: Math.random() * 100,
  biodiversityIndex: Math.random() * 10,
  location: [
    -122.4194 + (Math.random() - 0.5) * 2,
    37.7749 + (Math.random() - 0.5) * 2,
  ],
  timestamp: new Date().toISOString(),
});

export const generateMapMarkers = (): MapMarker[] => {
  return Array.from({ length: 10 }, (_, i) => ({
    id: `marker-${i}`,
    longitude: -122.4194 + (Math.random() - 0.5) * 2,
    latitude: 37.7749 + (Math.random() - 0.5) * 2,
    type: ['biodiversity', 'pollution', 'restoration'][Math.floor(Math.random() * 3)] as MapMarker['type'],
    value: Math.random() * 100,
  }));
};