import { MarineData } from '../types';

export const predictNextValues = (historicalData: MarineData[]): MarineData => {
  if (historicalData.length < 2) return generateBasePrediction();
  
  const lastPoints = historicalData.slice(-3);
  
  // Simple linear regression for predictions
  const temperature = calculateTrend(lastPoints.map(d => d.temperature));
  const pollutionLevel = calculateTrend(lastPoints.map(d => d.pollutionLevel));
  const biodiversityIndex = calculateTrend(lastPoints.map(d => d.biodiversityIndex));
  
  return {
    temperature: Math.max(0, Math.min(40, temperature)),
    pollutionLevel: Math.max(0, Math.min(100, pollutionLevel)),
    biodiversityIndex: Math.max(0, Math.min(10, biodiversityIndex)),
    location: lastPoints[lastPoints.length - 1].location,
    timestamp: new Date().toISOString(),
  };
};

const calculateTrend = (values: number[]): number => {
  if (values.length < 2) return values[0] || 0;
  const trend = values[values.length - 1] - values[values.length - 2];
  return values[values.length - 1] + trend;
};

const generateBasePrediction = (): MarineData => ({
  temperature: 25,
  pollutionLevel: 50,
  biodiversityIndex: 5,
  location: [-122.4194, 37.7749],
  timestamp: new Date().toISOString(),
});