import React, { useState, useEffect } from 'react';
import { DataCard } from './components/Dashboard/DataCard';
import { AlertSystem } from './components/Dashboard/AlertSystem';
import { MarineMap } from './components/Map/MarineMap';
import { TimeSeriesChart } from './components/Charts/TimeSeriesChart';
import { DataHeatmap } from './components/Heatmap/DataHeatmap';
import { PredictionCard } from './components/Predictions/PredictionCard';
import { MarineData, AlertConfig } from './types';
import { generateMockData, generateMapMarkers } from './utils/data';
import { predictNextValues } from './utils/predictions';

function App() {
  const [historicalData, setHistoricalData] = useState<MarineData[]>([]);
  const [currentData, setCurrentData] = useState<MarineData>(generateMockData());
  const [predictedData, setPredictedData] = useState<MarineData>(currentData);
  const [alertConfig, setAlertConfig] = useState<AlertConfig>({
    temperatureThreshold: 25,
    pollutionThreshold: 75,
    enabled: true,
  });

  useEffect(() => {
    const interval = setInterval(() => {
      const newData = generateMockData();
      setCurrentData(newData);
      setHistoricalData(prev => [...prev.slice(-19), newData]);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (historicalData.length > 0) {
      setPredictedData(predictNextValues(historicalData));
    }
  }, [historicalData]);

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">
          Marine Ecosystem Dashboard
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <DataCard
            title="Water Temperature"
            value={currentData.temperature}
            type="temperature"
            unit="°C"
          />
          <DataCard
            title="Pollution Level"
            value={currentData.pollutionLevel}
            type="pollution"
            unit="%"
          />
          <DataCard
            title="Biodiversity Index"
            value={currentData.biodiversityIndex}
            type="biodiversity"
            unit=""
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg p-4 shadow-md">
              <h2 className="text-xl font-semibold mb-4">Historical Trends</h2>
              <TimeSeriesChart data={historicalData} />
            </div>
          </div>
          <div className="space-y-4">
            <AlertSystem
              config={alertConfig}
              onConfigChange={setAlertConfig}
            />
            <PredictionCard
              current={currentData}
              predicted={predictedData}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="bg-white rounded-lg p-4 shadow-md">
            <h2 className="text-xl font-semibold mb-4">Temperature Heatmap</h2>
            <DataHeatmap data={historicalData} metric="temperature" />
          </div>
          <div className="bg-white rounded-lg p-4 shadow-md">
            <h2 className="text-xl font-semibold mb-4">Pollution Heatmap</h2>
            <DataHeatmap data={historicalData} metric="pollutionLevel" />
          </div>
          <div className="bg-white rounded-lg p-4 shadow-md">
            <h2 className="text-xl font-semibold mb-4">Biodiversity Heatmap</h2>
            <DataHeatmap data={historicalData} metric="biodiversityIndex" />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4 h-[500px]">
          <h2 className="text-xl font-semibold mb-4">Ecosystem Map</h2>
          <MarineMap markers={generateMapMarkers()} />
        </div>
      </div>
    </div>
  );
}

export default App;